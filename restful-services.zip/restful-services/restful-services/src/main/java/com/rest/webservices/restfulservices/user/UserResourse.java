package com.rest.webservices.restfulservices.user;

import java.net.URI;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
public class UserResourse {
  
	@Autowired
	 private UserDaoService service;

	
	//GET / users
	//retrive all users
	@GetMapping("/users")
	 public List<User> retrieveAllUsers() {
	 return service.findAll();
	 }
	
	//GET /user{id}
	/*@GetMapping("/users/{id}")
	 public User retrieveUser(@PathVariable int id) {
	 return service.findOne(id);
	 }
	 */
	
	//created and get details of user 
	// output created and return created uri
	
//	@PostMapping("/users")
//	 public void createUser(@RequestBody User user){
//	 User savedUser = service.save(user);
//	 } // this is without status
	
	
	 // input - details of user
	 // output - CREATED & Return the created URI
	 @PostMapping("/users")
	 public ResponseEntity<Object> createUser(@Valid @RequestBody User user) {
	 User savedUser = service.save(user);
	 // CREATED status that is link addresss
	 // /user/{id} savedUser.getId()
	 
	 URI location = ServletUriComponentsBuilder
	 .fromCurrentRequest()
	 .path("/{id}")
	  .buildAndExpand(savedUser.getId()).toUri();
	 
	 return ResponseEntity.created(location).build();
	
}	
	 
	 //this is for if we send request doesnot proper so we give some information while we send incorrect req
	 //standard exception structure
	 
	 /*
	 @GetMapping("/users/{id}")
	 public User retrieveUser(@PathVariable int id) {
	User user = service.findOne(id);
	if(user==null)
	throw new UserNotFoundException("id-"+id);
		 return resource;
	//hateoas
	//"all-users", SERVER_PATH + "/users"
	//retrieveAllUsers

	 } something prob so i stop this in middle
	 */
	 
	 
	 
	 
	 
	  // delete user
	 @DeleteMapping("/users/{id}")
	 public void deleteUser(@PathVariable int id) {
	 User user = service.deleteById(id);
	 
	 if(user==null)
	 throw new UserNotFoundException("id-"+ id); 
	 }
	 
	 }

	


