package com.rest.webservices.restfulservices.user;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
public class UserJPAResourse {
  
	@Autowired
	 private UserDaoService service;

	@Autowired
	private UserRepository ur;
	
	@Autowired
	private PostRepository pr;
	
	//GET / users
	//retrive all users
	@GetMapping("/jpa/users")
	 public List<User> retrieveAllUsers() {
	 return ur.findAll();
	 }
	
	
	/*
	//user find or not to know ....this process is used this is jpa resfule
	@GetMapping("/jpa/users/{id}")
	 public Resource retrieveUser(@PathVariable int id) 
	{
	 Optional<User> user = ur.findById(id);
	 if (!user.isPresent())
	 throw new UserNotFoundException("id-" +
	 id);
	 // "all-users", SERVER_PATH  "/users"
	 // retrieveAllUsers
	 Resource<User> resource = new Resource<User>(user.get());
	 ControllerLinkBuilder linkTo = 	linkTo(methodOn(this.getClass()).retrieveAllUsers());
	 resource.add(linkTo.withRel("all-users"));
	 // HATEOAS
	 return	 resource;
	 }
*/
	
	
	
	
	
	
	
	/*
	//GET /user{id}
	@GetMapping("/jpa/users/{id}")
	 public User retrieveUser(@PathVariable int id) {
	 return service.find(id);
	 }
	 */
	
	//created and get details of user 
	// output created and return created uri
	
//	@PostMapping("/users")
//	 public void createUser(@RequestBody User user){
//	 User savedUser = service.save(user);
//	 } // this is without status
	
	
	 // input - details of user
	 // output - CREATED & Return the created URI
	// this is for jpa and restful also.. if u want rest use service.save.. if u want jpa use ur.save
	 @PostMapping("/jpa/users")
	 public ResponseEntity<Object> createUser(@Valid @RequestBody User user) {
	 User savedUser = ur.save(user);
	 // CREATED status that is link addresss
	 // /user/{id} savedUser.getId()
	 
	 URI location = ServletUriComponentsBuilder
	 .fromCurrentRequest()
	 .path("/{id}")
	  .buildAndExpand(savedUser.getId()).toUri();
	 
	 return ResponseEntity.created(location).build();
	
}	
	 // delete user
	 @DeleteMapping("/jpa/users/{id}")
	 public void deleteUser(@PathVariable int id) {
	 ur.deleteById(id);
	 

	 } 
	 
	 // this is for jpa one to many  ... we get request from post details we get
	 @GetMapping("/jpa/users/{id}/posts")
	 public List<Post> retrieveAllUsers(@PathVariable int id) {
	 Optional<User> userOptional = ur.findById(id);
	
	 
	if(!userOptional.isPresent()) {
		 throw new UserNotFoundException("id-" + id);
		 }
	 	return userOptional.get().getPosts() ;
	 }
	 
	 //to creat a post 
	 @PostMapping("/jpa/users/{id}/posts")
	 public ResponseEntity<Object> createPost(@PathVariable int id, @RequestBody Post post) {
		 Optional<User> userOptional = ur.findById(id);
			
		 
			if(!userOptional.isPresent()) {
				 throw new UserNotFoundException("id-" + id);
				 }
	 
	 
	 User user= userOptional.get();
	 
	 // we create post reposiory interface
	 post.setUser(user);
	 pr.save(post);
	 
	 URI location = ServletUriComponentsBuilder .fromCurrentRequest().path("/{id}")
	  .buildAndExpand(post.getId()).toUri();
	 
	 return ResponseEntity.created(location).build();
	
}	
	 
	 
	 
	 
	 
	 
	 }

	 
	 //this is for if we send request doesnot proper so we give some information while we send incorrect req
	 //standard exception structure
//user find or not to know
	 /*
	 @GetMapping("/users/{id}")
	 public User retrieveUser(@PathVariable int id) {
	User user = service.findOne(id);
	if(user==null)
	throw new UserNotFoundException("id-"+id);
		 return resource;
	//hateoas
	//"all-users", SERVER_PATH + "/users"
	//retrieveAllUsers

	 } something prob so i stop this in middle
	 */
	 
	 
	 
	 
	 
	 
	


