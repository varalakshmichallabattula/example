package com.rest.webservices.restfulservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
