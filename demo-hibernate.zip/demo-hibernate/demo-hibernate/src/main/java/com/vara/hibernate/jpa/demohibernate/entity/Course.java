package com.vara.hibernate.jpa.demohibernate.entity;



import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;




@	Entity
@NamedQuery(name="query_getallcourses", query="select c FROM Course c")
//@Table(name="Course")
public class Course {
             
	@Id
	@GeneratedValue
   private Long id;
	
	@Column(nullable = false)
	  private String name;
	
	
	@OneToMany(mappedBy="course")
	  private List<Review> reviews = new ArrayList<>();
	
	@ManyToMany(mappedBy ="courses")
	private List<Student> students = new ArrayList<>();
	
	
	
	@UpdateTimestamp
		private  LocalDateTime lastDate;
	
	@CreationTimestamp
	private   LocalDateTime createdDate;
	
	  protected Course() {}
	  
	  public Course(String name) {
		  this.name =name;
	  }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	

	public List<Review> getReviews() {
		return reviews;
	}

	public void addReview(Review review) {
		this.reviews.add(review);
		
	}
	public void removeReview(Review review) {
		this.reviews.remove(review);
		
	}
	


	public List<Student> getStudents() {
		return students;
	}

	public void addStudent(Student student) {
		this.students.add(student);
	}

	public Long getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Course [name=" + name + "]";

}
}