package com.vara.hibernate.jpa.demohibernate;




import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.vara.hibernate.jpa.demohibernate.entity.Course;
import com.vara.hibernate.jpa.demohibernate.entity.FullTimeEmployee;
import com.vara.hibernate.jpa.demohibernate.entity.PartTimeEmployee;
import com.vara.hibernate.jpa.demohibernate.entity.Review;
import com.vara.hibernate.jpa.demohibernate.entity.Student;
import com.vara.hibernate.jpa.demohibernate.repository.CourseRepository;
import com.vara.hibernate.jpa.demohibernate.repository.EmployeeRepository;
import com.vara.hibernate.jpa.demohibernate.repository.StudentRepository;


@SpringBootApplication
public class DemoHibernateApplication implements CommandLineRunner {
	 private Logger logger = LoggerFactory.getLogger(this.getClass());
		@Autowired 
		private CourseRepository courseRepository;
		
		@Autowired 
		private StudentRepository studentRepository;
		
		@Autowired 
		private EmployeeRepository  employeeRepository;
		

		
		
	public static void main(String[] args) {
		SpringApplication.run(DemoHibernateApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {

		//studentRepository.saveStudentWithPassport();
		//repository.playWithEm();
		//courseRepository.addHardReviewsForCourse( );
//		List<Review> reviews = new ArrayList();
//		 reviews.add(new Review("5", "great stuff"));
//		 reviews.add(new Review("5", "great man "));
//		courseRepository.addReviewsForCourse(10003L, reviews );
        //studentRepository.insertStudentCourse();
		//studentRepository.insertStudentCourse(new Student("jack"), 
			//	new Course("microservies"));
		/*
		 * Inheritance
		 * 
		employeeRepository.insert( new PartTimeEmployee("jill", new BigDecimal("50")));
		employeeRepository.insert( new FullTimeEmployee("jack", new BigDecimal("10000")));
		// logger.info("All employees -> {}", employeeRepository.retrieveAllEmployees()); //single class
		
		logger.info("All fulltime employee -> {}", employeeRepository.retrieveAllFullTimeEmployees());
		logger.info("All part time employees -> {}", employeeRepository.retrieveAllPartTimeEmployees());
		
		*/
		
		
		
		
		
		
		
		
		
		
//		Course course = repository.findById(1000L);
// 	 	logger.info("course 10001 -> {}", course);
// 	 //	repository.deleteById(1000L);
// 	 	
// 	 	repository.save(new Course("microservues"));

//entity manager
	//repository.playWithEm();
//Course course = repository.findById(1000L);
// 	 	logger.info("course 10001 -> {}", course);
// 	 //	repository.deleteById(1000L);
// 	 	
// 	 	repository.save(new Course("microservues"));
	
	//entity manager
	//repository.playWithEm();

	}

}
