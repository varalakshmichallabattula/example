insert into course(id, name, created_date, last_date) 
values(1000,'jpa', sysdate(), sysdate());
insert into course (id, name, created_date, last_date) 
values(10001,'spring' , sysdate(), sysdate());
insert into course (id, name, created_date, last_date) 
values(10002,'boot', sysdate(), sysdate());
insert into course(id, name, created_date, last_date)
values(10003,'jsp' ,  sysdate(), sysdate());

insert into passport(id,number)
values(40001,'E123456');
insert into passport(id,number)
values(40002,'E123457');
insert into passport(id,number)
values(40003,'E123458');
insert into passport(id,number)
values(40004,'E123459');

insert into student(id,name, passport_id)
values(20001,'ranga ', 40001);
insert into student(id,name,passport_id)
values(20002,' adam',40002);
insert into student(id,name, passport_id)
values(20003,' jane', 40003);
insert into student(id,name,passport_id)
values(20004,'vara ', 40004);

insert into review(id,rating,description, course_id)
values(50001, '5',' great', 1000);
insert into review(id,rating,description, course_id)
values(50002, '6',' good', 1000);
insert into review(id,rating,description, course_id)
values(50003, '7',' verygood',10003);
insert into review(id,rating,description, course_id)
values(50005, '8',' excelent', 10003);


insert into student_course(student_id, course_id)
values(20001,1000);
insert into student_course(student_id, course_id)
values(20002,1000);
insert into student_course(student_id, course_id)
values(20003,1000);
insert into student_course(student_id, course_id)
values(20001,10003);





















