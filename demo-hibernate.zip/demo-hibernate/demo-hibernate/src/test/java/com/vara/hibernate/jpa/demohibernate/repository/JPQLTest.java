package com.vara.hibernate.jpa.demohibernate.repository;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.vara.hibernate.jpa.demohibernate.DemoHibernateApplication;
import com.vara.hibernate.jpa.demohibernate.entity.Course;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = DemoHibernateApplication.class)
public class JPQLTest {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	// to test cr
	@Autowired
	EntityManager em;

	@Test
	public void jpql_basictest() {
 Query query = em.createNamedQuery("query_getallcourses");
List resultList = query.getResultList();
		 
 logger.info("select c FROM Course c  ->{}", resultList );
	// output: Course [name=web services in100], Course [name=js----updated], Course [name=jpa], Course [name=spring], 
     //Course [name=boot], Course [name=jsp]	
	}
    
	
	
	@Test
	public void  jpql_typed() {
		
 TypedQuery<Course>  query= em.createNamedQuery("query_getallcourses", Course.class);
 List<Course> resultList = query.getResultList();
 logger.info("  select c FROM Course c ->{}", resultList    );
	
	}
	
	
	@Test
	public void  jpql_where() {
		
 TypedQuery<Course>  query= em.createQuery("select c FROM Course c where id= '1' ", Course.class);
 List<Course> resultList = query.getResultList();
 logger.info("  select c FROM Course c   where id= '1' ->{}", resultList    );
	
	}
	/*
	@Test
	public void  jpql_courses_without_students() {
		
 TypedQuery<Course>  query= em.createQuery("select c FROM Course c where c.students is empty", Course.class);
 List<Course> resultList = query.getResultList();
 logger.info("  resutlts->{}", resultList    );
	
	}
	
	
	
	@Test
	public void  jpql_courseswith 2_students() {
		
 TypedQuery<Course>  query= em.createQuery("select c from Course c where size(c.students ) >=2", Course.class);
 List<Course> resultList = query.getResultList();
 logger.info("  resutlts->{}", resultList    );
	
	}
	@Test
	public void  jpql_courseswith _orderby_students() {
		
 TypedQuery<Course>  query= em.createQuery("select c from Course c order by size(c.students ) desc", Course.class);
 List<Course> resultList = query.getResultList();
 logger.info("  resutlts->{}", resultList    );
	
	}
	
	@Test
	public void  jpql_passports_incertain_pattern_like_students() {
		
 TypedQuery<Student>  query= em.createQuery("select s from Student s where s.passport.numer like '%1234%' ", Student.class);
 List<Student> resultList = query.getResultList();
 logger.info("  resutlts->{}", resultList    );
	
	}
	
	joim
	public void join(){
	
	Query  query= em.createQuery("select c, s from Course c JOIN c.students s ");
 List<Object[]> resultList = query.getResultList();
 logger.info("  resutlts->{}", resultList.size() );
  for(Object[] result:resultList.size()){
  
  logger,info("course {} student{}", result[0], result[1]);
//	result[0]student
	//result[1];course
	
	@Test
	public void left_join(){
		Query query = em.createQuery("Select c, s from Course c LEFT JOIN c.students s");
		List<Object[]> resultList = query.getResultList();
		logger.info("Results Size -> {}", resultList.size());
		for(Object[] result:resultList){
			logger.info("Course{} Student{}", result[0], result[1]);
		}
	}

	@Test
	public void cross_join(){
		Query query = em.createQuery("Select c, s from Course c, Student s");
		List<Object[]> resultList = query.getResultList();
		logger.info("Results Size -> {}", resultList.size());
		for(Object[] result:resultList){
			logger.info("Course{} Student{}", result[0], result[1]);
		}
	
	
	
	
	
	}}
	
	left join ---> select c, s from c LEFT JOIN c.students s 
	crose--->select c, s from course c students s 
	
	*
	*
	*
	*
	*
	*
	*
	*
	*
	*
	*
	*
	*
	*
	*
	*
	*
	*
	*
	*
	*
	*/
	
	
	
	
	
	
	
	
	
	
	
	

}