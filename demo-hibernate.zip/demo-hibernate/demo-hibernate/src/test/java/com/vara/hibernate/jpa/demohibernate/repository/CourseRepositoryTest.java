package com.vara.hibernate.jpa.demohibernate.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.vara.hibernate.jpa.demohibernate.DemoHibernateApplication;
import com.vara.hibernate.jpa.demohibernate.entity.Course;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = DemoHibernateApplication.class)
public class CourseRepositoryTest {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	// to test cr
	@Autowired
	CourseRepository repository;

	@Test

	public void findById_basictest() {

		Course course = repository.findById(1000L);
		assertEquals("jpa", course.getName());
		logger.info("test is RUNNNNN!!!!!!!!!!!!!");
	}

	@Test
	@DirtiesContext // spring automatically reset sdata
	public void deleteById_basictest() {

		repository.deleteById(10002L);
		assertNull(repository.findById(10002L));

		logger.info("deleteis RUNNNNN!!!!!!!!!!!!!");
	}

	@Test
	@DirtiesContext // spring automatically reset sdata
	public void save_basictest() {
		// get a curser
		Course course = repository.findById(1000L);
		assertEquals("jpa", course.getName());
		// update details
		course.setName("jpa-updates");
		repository.save(course);
		// check value
		Course course1 = repository.findById(1000L);
		assertEquals("jpa-updates", course1.getName());
			}

	@Test
	@DirtiesContext // spring automatically reset sdata
	public void playWithEm() {
		
		repository.playWithEm();
	
	}
}
