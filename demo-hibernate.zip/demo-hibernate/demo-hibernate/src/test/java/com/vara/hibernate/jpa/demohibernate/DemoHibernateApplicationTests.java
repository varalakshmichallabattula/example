package com.vara.hibernate.jpa.demohibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
