package com.vara.hibernate.jpa.demohibernate.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import com.vara.hibernate.jpa.demohibernate.DemoHibernateApplication;
import com.vara.hibernate.jpa.demohibernate.entity.Course;
import com.vara.hibernate.jpa.demohibernate.entity.Passport;
import com.vara.hibernate.jpa.demohibernate.entity.Student;

import jakarta.persistence.EntityManager;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = DemoHibernateApplication.class)
public class StudentRepositoryTest {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	// to test cr
	@Autowired
	StudentRepository repository;
     
	@Autowired
	EntityManager em;
	
//	@Test
//	
//	public void someTest() {
//		repository.someDummyOperation();
//	}
	
	
	@Test
	@Transactional
     public void  retrieveStudentPassportDetails() {
      Student student = em.find(Student.class, 20001L);
      logger.info("student -> {}", student);
      logger.info("passport -> {} ", student.getPassport());
		
	}
	
	@Test
	@Transactional
     public void  retrievePassportStudentDetails() {
      Passport passport = em.find(Passport.class, 40001L);
      logger.info("passport  -> {}", passport );
      logger.info("student-> {} ",passport .getStudent());
		
	}

		
	}

